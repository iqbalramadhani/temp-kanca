/*
* Code from material angular
https://material.angularjs.org/latest/demo/sidenav
*/

(function() {

  angular.module("app.navigation.sidenav", ["ngMaterial", "ngMessages"])
      .controller('SidenavCtrl', SidenavCtrl)
      .controller('SidenavLeftCtrl', SidenavLeftCtrl)
      .controller('SidenavRightCtrl', SidenavRightCtrl);

  function SidenavCtrl($scope, $timeout, $mdSidenav, $log) {
      $scope.toggleLeft = function() {
          $mdSidenav('left').toggle()
              .then(function() {
                  $log.debug("toggle left is done");
              });
      };
      $scope.toggleRight = function() {
          $mdSidenav('right').toggle()
              .then(function() {
                  $log.debug("toggle RIGHT is done");
              });
      };
  }

  function SidenavLeftCtrl($scope, $timeout, $mdSidenav, $log) {
      $scope.close = function() {
          $mdSidenav('left').close()
              .then(function() {
                  $log.debug("close LEFT is done");
              });
      };
  }

  function SidenavRightCtrl($scope, $timeout, $mdSidenav, $log) {
      $scope.close = function() {
          $mdSidenav('right').close()
              .then(function() {
                  $log.debug("close RIGHT is done");
              });
      };
  }

})();
