(function() {

    /*
     Application navigation controllers
     */

    angular.module("app.navigation", [])
        .controller("NavCtrl", ["$scope", "$timeout", "$mdSidenav", "$mdUtil", "$log", "$state", "$location", "$mdMedia", "config", NavCtrl])
        .controller("MenuCtrl", ['$location', '$state', MenuCtrl]);

    function NavCtrl($scope, $timeout, $mdSidenav, $mdUtil, $log, $state, $location, $mdMedia, config) {
        this.sidebar_opened = $mdMedia('gt-sm') && config.sidebar_default_open;

        this.checkIfOwnPage = function() {
            return _.contains(["404", "500", "signin", "signup", "forgot-password", "lock-screen"], $state.current.name);
        };
    }

    function MenuCtrl($location, $state) {

        this.goToUrl = function(url) {
            $location.path(url);
        };

        this.menu_sections = [{
            name: 'translate_table.navigation.DASHBOARD.TITLE',
            is_toggle: true,
            toggled: false,
            icon: 'dist/img/icons/ic_insert_chart_24px.svg',
            menu_items: [{
                name: 'translate_table.navigation.DASHBOARD.subitems.DASHBOARD_1',
                url: 'dashboard'
            }, {
                name: 'translate_table.navigation.DASHBOARD.subitems.DASHBOARD_ANALYSIS',
                url: 'dashboard1'
            }, {
                name: 'translate_table.navigation.DASHBOARD.subitems.DASHBOARD_SOCIAL',
                url: 'dashboard2'
            }]
        }, {
            name: 'translate_table.navigation.UI.TITLE',
            is_toggle: true,
            toggled: false,
            icon: 'dist/img/icons/ic_layers_24px.svg',
            menu_items: [{
                name: 'translate_table.navigation.UI.subitems.UI_BUTTONS',
                url: 'buttons'
            }, {
                name: 'translate_table.navigation.UI.subitems.UI_FABS',
                url: 'fabs'
            }, {
                name: 'translate_table.navigation.UI.subitems.UI_CARDS',
                url: 'cards'
            }, {
                name: 'translate_table.navigation.UI.subitems.UI_COLORS',
                url: 'colors'
            }, {
                name: 'translate_table.navigation.UI.subitems.UI_WIDGETS',
                url: 'widgets'
            }, {
                name: 'translate_table.navigation.UI.subitems.UI_CHIPS',
                url: 'chips'
            }, {
                name: 'translate_table.navigation.UI.subitems.UI_PROGRESS',
                url: 'progress'
            }, {
                name: 'translate_table.navigation.UI.subitems.UI_MESSAGES',
                url: 'messages'
            }, {
                name: 'translate_table.navigation.UI.subitems.UI_TABS',
                url: 'tabs'
            }, {
                name: 'translate_table.navigation.UI.subitems.UI_TIMELINE',
                url: 'timeline'
            }, {
                name: 'translate_table.navigation.UI.subitems.UI_MATERIAL_ICONS',
                url: 'icons'
            }, {
                name: 'translate_table.navigation.UI.subitems.UI_GRIDS',
                url: 'grids'
            }]
        }, {
            name: 'translate_table.navigation.CUSTOM_PAGES.TITLE',
            is_toggle: true,
            icon: 'dist/img/icons/ic_pages_24px.svg',
            menu_items: [{
                name: 'translate_table.navigation.CUSTOM_PAGES.subitems.CP_PROFILE',
                url: 'profile'
            }, {
                name: 'translate_table.navigation.CUSTOM_PAGES.subitems.CP_LOGIN',
                url: 'signin'
            }, {
                name: 'translate_table.navigation.CUSTOM_PAGES.subitems.CP_SIGNUP',
                url: 'signup'
            }, {
                name: 'translate_table.navigation.CUSTOM_PAGES.subitems.CP_FORGOT_PASSWORD',
                url: 'forgot-password'
            }, {
                name: 'translate_table.navigation.CUSTOM_PAGES.subitems.CP_LOCK',
                url: 'lock-screen'
            }, {
                name: 'translate_table.navigation.CUSTOM_PAGES.subitems.CP_CONTACT',
                url: 'contact'
            }, {
                name: 'translate_table.navigation.CUSTOM_PAGES.subitems.CP_500',
                url: '500'
            }, {
                name: 'translate_table.navigation.CUSTOM_PAGES.subitems.CP_404',
                url: '404'
            }]
        }, {
            name: 'translate_table.navigation.CHARTS.TITLE',
            is_toggle: true,
            toggled: false,
            icon: 'dist/img/icons/ic_trending_up_24px.svg',
            menu_items: [{
                name: 'translate_table.navigation.CHARTS.subitems.CHARTS_FLOT',
                url: 'flot-charts'
            }, {
                name: 'translate_table.navigation.CHARTS.subitems.CHARTS_JS',
                url: 'chartjs'
            }, {
                name: 'translate_table.navigation.CHARTS.subitems.CHARTS_MORRIS',
                url: 'morris'
            }, {
                name: 'translate_table.navigation.CHARTS.subitems.CHARTS_D3',
                url: 'd3'
            }, {
                name: 'translate_table.navigation.CHARTS.subitems.CHARTS_OTHER',
                url: 'other-charts'
            }]
        }, {
            name: 'translate_table.navigation.TABLES.TITLE',
            is_toggle: true,
            toggled: false,
            icon: 'dist/img/icons/ic_view_module_24px.svg',
            menu_items: [{
                name: 'translate_table.navigation.TABLES.subitems.TABLE_STATIC',
                url: 'tables-static'
            }, {
                name: 'translate_table.navigation.TABLES.subitems.TABLE_RESPONSIVE',
                url: 'tables-responsive'
            }, {
                name: 'translate_table.navigation.TABLES.subitems.TABLE_DYNAMIC',
                url: 'tables-dynamic'
            }]
        }, {
            name: 'translate_table.navigation.FORMS.TITLE',
            is_toggle: true,
            toggled: false,
            icon: 'dist/img/icons/ic_transform_24px.svg',
            menu_items: [{
                name: 'translate_table.navigation.FORMS.subitems.FORMS_ELEMENTS',
                url: 'form-elements'
            }, {
                name: 'translate_table.navigation.FORMS.subitems.FORMS_VALIDATION',
                url: 'form-validation'
            }]
        }, {
            name: 'translate_table.navigation.CHAT.TITLE',
            is_toggle: true,
            toggled: false,
            icon: 'dist/img/icons/ic_chat_24px.svg',
            url: 'chat'
        }, {
            name: 'translate_table.navigation.TASKS.TITLE',
            is_toggle: true,
            toggled: false,
            icon: 'dist/img/icons/ic_done_all_24px.svg',
            url: 'tasks'
        }];

        this.getActiveParent = function(items) {
            return _.find(items, function(value) {
                return value.url === $state.current.name || $state.current.name.startsWith(value + ".");
            });
        };

        this.getActiveCurrent = function(url) {
            return url == $state.current.name || $state.current.name.startsWith(url + ".");
        };

        this.toggle = function(index) {
            var $this = this;
            this.menu_sections.map(function(ix, position) {
                var toggle = $this.menu_sections[index].toggled ? false : true;
                $this.menu_sections[position].toggled = position !== index ? false : toggle;
            });
            $(".main-menu").children("li:nth-child(" + (index + 1) + ")").toggleClass("open").find("ul").stop().slideToggle(300, function() {
                $(".main-menu").children("li:nth-child(" + (index + 1) + ")").siblings().removeClass("open").find("ul").stop().slideUp(300);
            });
        };
    }

})();
