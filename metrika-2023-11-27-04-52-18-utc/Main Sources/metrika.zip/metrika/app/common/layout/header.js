(function () {


    angular.module("app.header", [])
        .component("branding", {
            templateUrl: 'app/common/layout/templates/header-app-name.html',
            controller: function ($mdSidenav, $mdUtil) {
                this.icon = "ic_functions_48px";

                this.toggleLeft = buildToggler('left');

                /**
                 * Build handler to open/close a SideNav; when animation finishes
                 * report completion in console
                 */
                function buildToggler(navID) {
                    var debounceFn = $mdUtil.debounce(function () {
                        $(".view-container").toggleClass("slided-right");
                        $(".header__menu-button").toggleClass("toggled");
                        $mdSidenav(navID)
                            .toggle()
                            .then(function () {

                            });
                    }, 200);
                    return debounceFn;
                }
            }
        })
        .component("headerUser", {
            templateUrl: 'app/common/layout/templates/header-user.html',
            controllerAs: 'headeruser',
            controller: function () {
                this.user_items = [{
                    name: 'Settings',
                    icon: 'ic_settings_24px',
                    link: '#/pages/profile',
                    color_class: 'md-primary'
                }, {
                        name: 'My mail',
                        icon: 'ic_mail_24px',
                        link: '#/pages/profile',
                        color_class: 'md-accent'
                    }, {
                        name: 'My Tasks',
                        icon: 'ic_done_all_24px',
                        link: '#/pages/profile',
                        color_class: 'md-accent'
                    }, {
                        name: 'Logout',
                        icon: 'ic_power_settings_new_24px',
                        link: '#/pages/profile',
                        color_class: 'md-accent'
                    }];
            }
        })
        .component("headerRedialMenu", {
            templateUrl: 'app/common/layout/templates/header-redial-menu.html',
            controllerAs: 'header_redial_menu',
            controller: function ($mdDialog) {
                var originatorEv;
                this.openMenu = function ($mdOpenMenu, ev) {
                    originatorEv = ev;
                    $mdOpenMenu(ev);
                };
                this.notificationsEnabled = true;
                this.toggleNotifications = function () {
                    this.notificationsEnabled = !this.notificationsEnabled;
                };
                this.redial = function () {
                    $mdDialog.show(
                        $mdDialog.alert()
                            .targetEvent(originatorEv)
                            .clickOutsideToClose(true)
                            .parent('body')
                            .title('Suddenly, a redial')
                            .content('You just called a friend; who told you the most amazing story. Have a cookie!')
                            .ok('That was easy')
                    );
                    originatorEv = null;
                };
                this.checkVoicemail = function () {
                    // This never happens.
                };
            }
        })
        .component("headerTranslateMenu", {
            templateUrl: 'app/common/layout/templates/header-translate-menu.html',
            controllerAs: 'translatemenu',
            controller: function ($translate) {
                this.activeLanguage = $translate.preferredLanguage();
                //@todo - replace with $translate.getAvailableLanguageKeys (see https://github.com/angular-translate/angular-translate/pull/1424)
                this.availableLanguages = [
                    'us',
                    'cn',
                    'in',
                    'pt',
                    'de',
                ];
                this.setLang = function (langKey) {
                    // You can change the language during runtime
                    this.activeLanguage = langKey;
                    $translate.use(langKey);
                };
            }
        });


})();
