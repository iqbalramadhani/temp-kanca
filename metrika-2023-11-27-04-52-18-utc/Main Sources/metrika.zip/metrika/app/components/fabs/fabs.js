/*
* Code from material angular
https://material.angularjs.org/latest/demo/fabSpeedDial
https://material.angularjs.org/latest/demo/fabToolbar
*/

(function() {

  angular.module('app.fabs', ['ngMaterial', 'ngMessages'])
    .controller('HomeFabCtrl',
    function () {
      this.isOpen = false;
      this.selectedMode = 'md-fling';
      this.selectedDirection = 'left';
    })
    .controller('FabToolbarCtrl',
    function ($scope) {
      this.isOpen = false;
      this.selectedMode = 'md-fling';
      this.selectedDirection = 'left';
      this.count = 0;
    })
    .controller('FabSpeedDialCtrl',
    function () {
      this.topDirections = ['left', 'up'];
      this.bottomDirections = ['down', 'right'];
      this.isOpen = false;
      this.availableModes = ['md-fling', 'md-scale'];
      this.selectedMode = 'md-fling';
      this.availableDirections = ['up', 'down', 'left', 'right'];
      this.selectedDirection = 'right';
    });
})();
