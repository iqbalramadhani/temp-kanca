/*
 D3 Pie charts angularJs
 https://github.com/n3-charts/pie-chart
 */

(function() {

    angular.module("app.chart.ctrls")
        .controller("piechartD3Ctrl", ["$scope", "D3PieSrv", piechartD3Ctrl]);

    function piechartD3Ctrl($scope, D3PieSrv) {
        //First pie chart
        $scope.pieData = D3PieSrv;

        D3PieSrv.getData(function(data) {
            // no need to read data because its binded to $scope
            // You can however process something only after the data comes back
        });

        setInterval(function() {
            $scope.pieData.rawData.smallPie1.data[0].value = parseInt(((Math.random() * 6) + 4) * 10);
            $scope.pieData.rawData.smallPie2.data[0].value = parseInt(((Math.random() * 6) + 4) * 10);
            $scope.pieData.rawData.smallPie3.data[0].value = parseInt(((Math.random() * 6) + 4) * 10);
            $scope.$apply();
        }, 10000);
    }
})();
