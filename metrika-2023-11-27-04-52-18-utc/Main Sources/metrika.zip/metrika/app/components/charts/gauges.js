/*
 Gauge charts
 */

(function() {

    angular.module("app.chart.ctrls")
        .controller("gaugeCtrl", ["$scope", "config", "$rootScope", "gaugesSrv", gaugesCtrl]);

    function gaugesCtrl($scope, config, $rootScope, gaugesSrv) {
        var data = gaugesSrv;

        $scope.gaugeHome = {
            gaugeOptions: {
                lines: 12,
                angle: 0,
                lineWidth: 0.47,
                pointer: {
                    length: 0.6,
                    strokeWidth: 0.03,
                    color: "#555555"
                },
                limitMax: "false",
                colorStart: $rootScope.RGB2HTML($rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade)),
                colorStop: $rootScope.RGB2HTML($rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade)),
                strokeColor: "#F5F5F5",
                generateGradient: !0,
                percentColors: [
                    [0, $rootScope.RGB2HTML($rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade))],
                    [1, $rootScope.RGB2HTML($rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade))]
                ]
            }
        };
        $scope.gauge1 = {
            gaugeOptions: {
                lines: 12,
                angle: 0,
                lineWidth: 0.47,
                pointer: {
                    length: 0.6,
                    strokeWidth: 0.03,
                    color: "#555555"
                },
                limitMax: "false",
                colorStart: $rootScope.RGB2HTML($rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade)),
                colorStop: $rootScope.RGB2HTML($rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade)),
                strokeColor: "#F5F5F5",
                generateGradient: !0,
                percentColors: [
                    [0, $rootScope.RGB2HTML($rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade))],
                    [1, $rootScope.RGB2HTML($rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade))]
                ]
            }
        };
        $scope.gauge2 = {
            gaugeOptions: {
                lines: 12,
                angle: 0,
                lineWidth: 0.47,
                pointer: {
                    length: 0.6,
                    strokeWidth: 0.03,
                    color: "#555555"
                },
                limitMax: "false",
                colorStart: $rootScope.RGB2HTML($rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade)),
                colorStop: $rootScope.RGB2HTML($rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade)),
                strokeColor: "#F5F5F5",
                generateGradient: !0,
                percentColors: [
                    [0, $rootScope.RGB2HTML($rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade))],
                    [1, $rootScope.RGB2HTML($rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade))]
                ]
            }
        };
        $scope.gauge3 = {
            gaugeOptions: {
                lines: 12,
                angle: 0,
                lineWidth: 0.47,
                pointer: {
                    length: 0.6,
                    strokeWidth: 0.03,
                    color: "#555555"
                },
                limitMax: "false",
                colorStart: config.color_warning,
                colorStop: config.color_warning,
                strokeColor: "#F5F5F5",
                generateGradient: !0,
                percentColors: [
                    [0, config.color_warning],
                    [1, config.color_warning]
                ]
            }
        };

        gaugesSrv.getData(function(data) {
            // no need to read data because its binded to $scope
            // You can however process something only after the data comes back
            $scope.gaugeHome.gaugeData = data.gaugeHome;
            $scope.gauge1.gaugeData = data.gauge1;
            $scope.gauge2.gaugeData = data.gauge2;
            $scope.gauge3.gaugeData = data.gauge3;
        });
    }

    /*
     Charting directives
     Provides custom directives for charting elements
     */

    angular.module("app.chart.directives")
        .directive("gaugeChart", [
            function() {
                return {
                    scope: {
                        gaugeData: "=",
                        gaugeOptions: "="
                    },
                    link: function(scope, ele) {
                        var data, gauge, options;

                        if (scope.gaugeData) {
                            data = scope.gaugeData;
                            options = scope.gaugeOptions;

                            gauge = new Gauge(ele[0]).setOptions(options);
                            gauge.maxValue = data.maxValue;
                            gauge.animationSpeed = data.animationSpeed;
                            gauge.set(data.val);
                        }

                        //Update when charts data changes
                        scope.$watch(function() {
                            return scope.gaugeData;
                        }, function(value) {
                            if (!value) return;

                            data = scope.gaugeData;
                            options = scope.gaugeOptions;

                            if (data.maxValue) {
                                //only update if there is data
                                gauge = new Gauge(ele[0]).setOptions(options);
                                gauge.maxValue = data.maxValue;
                                gauge.animationSpeed = data.animationSpeed;
                                gauge.set(data.val);
                            }
                        });
                    }
                };
            }
        ]);

})();
