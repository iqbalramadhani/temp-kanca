/*
 Morris charts angularJs
 http://morrisjs.github.io/morris.js/
 */

(function() {

    angular.module("app.chart.ctrls")
        .controller("morrisChartCtrl", ["$scope", "config", "$rootScope", "morrisSrv", morrisChartCtrl]);

    function morrisChartCtrl($scope, config, $rootScope, morrisSrv) {

        $scope.simpleColors = [$rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade)];
        $scope.comboColors = [$rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade), $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade), config.color_warning];
        $scope.doughnutColors = [$rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade), $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade), config.color_warning, config.danger_color];

        morrisSrv.getData(function(data) {
            $scope.mainData = data.mainData;
            $scope.simpleData = data.simpleData;
            $scope.comboData = data.comboData;
            $scope.donutData = data.donutData;
        });
    }

    /*
     Charting directives
     Provides custom directives for charting elements
     */

    angular.module("app.chart.directives")
        .directive("morrisChart", [
            function() {
                return {
                    scope: {
                        data: "="
                    },
                    link: function(scope, ele, attrs) {
                        var colors, data, func, options, chart;

                        printChart();

                        function printChart() {
                            switch (data = scope.data, attrs.type) {
                                case "line":
                                    return colors = void 0 === attrs.lineColors || "" === attrs.lineColors ? null : JSON.parse(attrs.lineColors), options = {
                                        element: ele[0],
                                        data: data,
                                        resize: true,
                                        xkey: attrs.xkey,
                                        ykeys: JSON.parse(attrs.ykeys),
                                        labels: JSON.parse(attrs.labels),
                                        lineWidth: attrs.lineWidth || 2,
                                        lineColors: colors || ["#0b62a4", "#7a92a3", "#4da74d", "#afd8f8", "#edc240", "#cb4b4b", "#9440ed"]
                                    }, chart = new Morris.Line(options), setTimeout(function() {
                                        chart.redraw();
                                    }, 1), $(window).resize(function() {
                                        chart.redraw();
                                    });
                                case "area":
                                    return colors = void 0 === attrs.lineColors || "" === attrs.lineColors ? null : JSON.parse(attrs.lineColors), options = {
                                        element: ele[0],
                                        data: data,
                                        resize: true,
                                        xkey: attrs.xkey,
                                        ykeys: JSON.parse(attrs.ykeys),
                                        labels: JSON.parse(attrs.labels),
                                        lineWidth: attrs.lineWidth || 2,
                                        lineColors: colors || ["#0b62a4", "#7a92a3", "#4da74d", "#afd8f8", "#edc240", "#cb4b4b", "#9440ed"],
                                        behaveLikeLine: attrs.behaveLikeLine || !1,
                                        fillOpacity: attrs.fillOpacity || "auto",
                                        pointSize: attrs.pointSize || 4
                                    }, chart = new Morris.Area(options), setTimeout(function() {
                                        chart.redraw();
                                    }, 1), $(window).resize(function() {
                                        chart.redraw();
                                    });
                                case "bar":
                                    return colors = void 0 === attrs.barColors || "" === attrs.barColors ? null : JSON.parse(attrs.barColors), options = {
                                        element: ele[0],
                                        data: data,
                                        resize: true,
                                        xkey: attrs.xkey,
                                        ykeys: JSON.parse(attrs.ykeys),
                                        labels: JSON.parse(attrs.labels),
                                        barColors: colors || ["#0b62a4", "#7a92a3", "#4da74d", "#afd8f8", "#edc240", "#cb4b4b", "#9440ed"],
                                        stacked: attrs.stacked || null
                                    }, chart = new Morris.Bar(options), setTimeout(function() {
                                        chart.redraw();
                                    }, 1), $(window).resize(function() {
                                        chart.redraw();
                                    });
                                case "donut":
                                    /*jslint evil: true */
                                    return colors = void 0 === attrs.colors || "" === attrs.colors ? null : JSON.parse(attrs.colors), options = {
                                        element: ele[0],
                                        data: data,
                                        resize: true,
                                        colors: colors || ["#0B62A4", "#3980B5", "#679DC6", "#95BBD7", "#B0CCE1", "#095791", "#095085", "#083E67", "#052C48", "#042135"]
                                    }, attrs.formatter && (func = new Function("y", "data", attrs.formatter), options.formatter = func), chart = new Morris.Donut(options), setTimeout(function() {
                                        chart.redraw();
                                    }, 1), $(window).resize(function() {
                                        chart.redraw();
                                    });
                            }
                        }

                        //Update when charts data changes
                        scope.$watch(function() {
                            return scope.data;
                        }, function(value) {
                            if (!value) return;
                            printChart();
                        });
                    }
                };
            }
        ]);

})();
