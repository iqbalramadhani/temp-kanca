/*
 D3 line charts angularJs
 https://github.com/n3-charts/line-chart
 color: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade)
 */

(function() {

    angular.module("app.chart.ctrls")
        .controller("lineD3Ctrl", ['$scope', 'config', '$rootScope', 'D3LineSrv', lineD3Ctrl]);

    function lineD3Ctrl($scope, config, $rootScope, D3LineSrv) {

        //replace $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade)

        $scope.lineChart = {
            options: {
                margin: {
                    top: 5
                },
                series: [{
                    axis: "y",
                    dataset: "numerical",
                    key: "val_0",
                    label: "A multi series",
                    color: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                    type: ["dot", "line", "area"],
                    id: "mySeries0"
                }],
                axes: {
                    x: {
                        key: "x"
                    }
                }
            }
        };

        $scope.lineChart.data = D3LineSrv;

        D3LineSrv.getData(function(data) {
            // no need to read data because its binded to $scope
            // You can however process something only after the data comes back
        });
    }

})();
