/*
 Chart module initialization
 */

(function() {

    angular.module("app.chart.ctrls", []);
    angular.module("app.chart.directives", []);

})();
