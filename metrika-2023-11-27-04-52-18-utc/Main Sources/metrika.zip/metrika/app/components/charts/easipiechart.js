/*
 Easipie charts
 https://rendro.github.io/easy-pie-chart/
 */

(function() {

    angular.module("app.chart.ctrls")
        .controller("chartingCtrl", ["$scope", "config", "$rootScope", chartingCtrl]);

    function chartingCtrl($scope, config, $rootScope) {
        return $scope.easypiesquare1 = {
                percent: 34,
                options: {
                    trackColor: config.chart_lines,
                    scaleColor: false,
                    animate: 3000,
                    rotate: 270,
                    barColor: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                    lineCap: "butt",
                    color: $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade),
                    size: 130,
                    lineWidth: 12,
                },
                name: "Task performance"
            },
            $scope.easypiewater = {
                percent: 65,
                options: {
                    lineWidth: 70,
                    trackColor: '#fff',
                    barColor: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                    scaleColor: '#fff',
                    size: 130,
                    lineCap: 'butt',
                    rotate: 90,
                    animate: 5000,
                },
                name: "Achievements"
            },
            $scope.easypie1 = {
                percent: 25,
                options: {
                    animate: {
                        duration: 1e2,
                        enabled: !0
                    },
                    barColor: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                    lineCap: "round",
                    size: 130,
                    lineWidth: 8
                },
                name: "Bounce rate"
            },
            $scope.easypie2 = {
                percent: 35,
                options: {
                    animate: {
                        duration: 1e2,
                        enabled: !0
                    },
                    barColor: $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade),
                    lineCap: "round",
                    size: 130,
                    lineWidth: 8
                },
                name: "Daily active user activation"
            },
            $scope.easypie3 = {
                percent: 87,
                options: {
                    animate: {
                        duration: 1e2,
                        enabled: !0
                    },
                    barColor: config.color_warning,
                    lineCap: "round",
                    size: 130,
                    lineWidth: 8
                },
                name: "registration / unique visit"
            },
            $scope.easypiesmall1 = {
                percent: 25,
                options: {
                    animate: {
                        duration: 1e2,
                        enabled: !0
                    },
                    trackColor: false,
                    scaleColor: false,
                    barColor: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                    lineCap: "round",
                    size: 67,
                    lineWidth: 5
                },
                name: "Bounce rate"
            },
            $scope.easypiemedium1 = {
                percent: 45,
                options: {
                    animate: {
                        duration: 1e2,
                        enabled: !0
                    },
                    trackColor: '#dedede',
                    scaleColor: '#dedede',
                    barColor: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                    lineCap: "round",
                    size: 80,
                    lineWidth: 5
                },
                name: "Bounce rate"
            },
            $scope.easypiesmall2 = {
                percent: 35,
                options: {
                    animate: {
                        duration: 1e2,
                        enabled: !0
                    },
                    trackColor: config.chart_lines,
                    scaleColor: config.chart_lines,
                    barColor: config.color_warning,
                    lineCap: "round",
                    size: 67,
                    lineWidth: 5
                },
                name: "Daily active user activation"
            },
            $scope.easypiesmall3 = {
                percent: 87,
                options: {
                    animate: {
                        duration: 1e2,
                        enabled: !0
                    },
                    trackColor: config.chart_lines,
                    scaleColor: config.chart_lines,
                    barColor: config.danger_color,
                    lineCap: "round",
                    size: 67,
                    lineWidth: 5
                },
                name: "registration / unique visit"
            };
    }

})();
