/*
 Chartjs
 http://www.chartjs.org/
 */

(function() {

    angular.module("app.chart.ctrls")
        .controller("chartjsCtrl", ["$scope", "config", "$rootScope", "chartJsSrv", chartjsCtrl]);

    function chartjsCtrl($scope, config, $rootScope, chartJsSrv) {

        $scope.chartjsLine = {
            labels: ["January", "February", "March", "April", "May", "June", "July"],
            datasets: [{
                label: "My First dataset",
                fillColor: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                strokeColor: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                pointColor: "#fff",
                pointStrokeColor: "#fff",
                pointHighlightFill: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                pointHighlightStroke: "rgba(220,220,220,1)",
                data: []
            }, {
                label: "My Second dataset",
                fillColor: config.color_warning,
                strokeColor: config.color_warning,
                pointColor: "#fff",
                pointStrokeColor: "#fff",
                pointHighlightFill: config.color_warning,
                pointHighlightStroke: "rgba(151,187,205,1)",
                data: []
            }]
        };
        $scope.chartjsBar = {
            labels: ["January", "February", "March", "April", "May", "June", "July"],
            datasets: [{
                label: "My First dataset",
                fillColor: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                strokeColor: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                highlightFill: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                highlightStroke: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                data: []
            }, {
                label: "My Second dataset",
                fillColor: config.color_warning,
                strokeColor: config.color_warning,
                highlightFill: config.color_warning,
                highlightStroke: config.color_warning,
                data: []
            }]
        };
        $scope.chartjsRadar = {
            labels: ["Eating", "Drinking", "Sleeping", "Designing", "Coding", "Cycling", "Running"],
            datasets: [{
                label: "My First dataset",
                fillColor: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                strokeColor: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                pointColor: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                data: []
            }, {
                label: "My Second dataset",
                fillColor: config.color_warning,
                strokeColor: config.color_warning,
                pointColor: config.color_warning,
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: config.color_warning,
                data: []
            }]
        };
        $scope.chartjsPolarArea = [{
            value: 300,
            color: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
            highlight: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
            label: "Primary"
        }, {
            value: 50,
            color: $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade),
            highlight: $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade),
            label: "Secondary"
        }, {
            value: 100,
            color: config.color_warning,
            highlight: config.color_warning,
            label: "Third"
        }, {
            value: 40,
            color: config.danger_color,
            highlight: config.danger_color,
            label: "Four"
        }, {
            value: 120,
            color: "#503f3c",
            highlight: "#503f3c",
            label: "Dark Brown"
        }];
        $scope.chartjsPie = [{
            value: 300,
            color: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
            highlight: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
            label: "Primary"
        }, {
            value: 50,
            color: $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade),
            highlight: $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade),
            label: "Secondary"
        }, {
            value: 100,
            color: config.color_warning,
            highlight: config.color_warning,
            label: "Third"
        }];

        $scope.chartjsDoughnut = [{
            value: 300,
            color: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
            highlight: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
            label: "Primary"
        }, {
            value: 50,
            color: $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade),
            highlight: $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade),
            label: "Secondary"
        }, {
            value: 100,
            color: config.color_warning,
            highlight: config.color_warning,
            label: "Third"
        }];


        chartJsSrv.getData(function(data) {
            //replace with _.each
            $scope.chartjsLine.datasets[0].data = data.chartjsLine.datasets[0];
            $scope.chartjsLine.datasets[1].data = data.chartjsLine.datasets[1];

            $scope.chartjsBar.datasets[0].data = data.chartjsBar.datasets[0];
            $scope.chartjsBar.datasets[1].data = data.chartjsBar.datasets[1];

            $scope.chartjsRadar.datasets[0].data = data.chartjsRadar.datasets[0];
            $scope.chartjsRadar.datasets[1].data = data.chartjsRadar.datasets[1];
        });
    }

    /*
     Charting directives
     Provides custom directives for charting elements
     */

    angular.module("app.chart.directives")
        .directive('chart',
            function() {
                var baseWidth = 600;
                var baseHeight = 400;

                return {
                    restrict: 'E',
                    template: '<canvas></canvas>',
                    scope: {
                        chartObject: "=value",
                        data: "="
                    },
                    link: function(scope, element, attrs) {
                        var canvas = element.find('canvas')[0],
                            context = canvas.getContext('2d'),
                            chart;
                        var options = {
                            responsive: true,
                            maintainAspectRatio: true
                        };

                        var chartType = attrs.type;

                        chart = new Chart(context);

                        printChart();

                        function printChart() {
                            chart[chartType](scope.data, options);
                        }

                        //Update when charts data changes
                        scope.$watch("data", function(value) {
                            if (value) {
                                printChart();
                            }
                        }, true);
                    }
                };
            });


})();
