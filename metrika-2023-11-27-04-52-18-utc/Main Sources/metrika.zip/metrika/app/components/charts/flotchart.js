/*
 Flot charts
 http://www.flotcharts.org/
 */

(function() {

    angular.module("app.chart.ctrls")
        .controller("flotChartCtrl", ["$scope", "config", "$rootScope", "flotSrv", flotChartCtrl]);

    function flotChartCtrl($scope, config, $rootScope, flotSrv) {
        var areaChart, barChart, lineChart1, lineChart1Small;

        $scope.line1 = {
            data: [],
            options: {
                series: {
                    lines: {
                        show: !0,
                        fill: !1,
                        lineWidth: 3,
                        fillColor: {
                            colors: [{
                                opacity: 0.3
                            }, {
                                opacity: 0.3
                            }]
                        }
                    },
                    points: {
                        show: !0,
                        lineWidth: 3,
                        fill: !0,
                        fillColor: "#ffffff",
                        symbol: "circle",
                        radius: 5
                    },
                    shadowSize: 0

                },
                colors: [$rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade), $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade)],
                tooltip: !0,
                tooltipOpts: {
                    defaultTheme: !1,
                    content: '<div class="tooltip-header">%s</div>' +
                        '<div class="tooltip-body">%y unique visitors</div>',
                    shifts: {
                        x: -95,
                        y: 25
                    }
                },
                grid: {
                    hoverable: !0,
                    clickable: !0,
                    tickColor: config.chart_lines,
                    borderWidth: 1,
                    borderColor: config.chart_lines
                },
                xaxis: {
                    ticks: [
                        [1, "Jan."],
                        [2, "Feb."],
                        [3, "Mar."],
                        [4, "Apr."],
                        [5, "May"],
                        [6, "June"],
                        [7, "July"],
                        [8, "Aug."],
                        [9, "Sept."],
                        [10, "Oct."],
                        [11, "Nov."],
                        [12, "Dec."]
                    ]
                }
            }
        };

        $scope.line1Small = {
            data: [],
            options: {
                series: {
                    lines: {
                        show: !0,
                        fill: !1,
                        lineWidth: 2,
                        fillColor: {
                            colors: [{
                                opacity: 0.3
                            }, {
                                opacity: 0.3
                            }]
                        }
                    },
                    points: {
                        show: !0,
                        lineWidth: 2,
                        fill: !0,
                        fillColor: "#ffffff",
                        symbol: "circle",
                        radius: 3
                    },
                    shadowSize: 0

                },
                colors: [$rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade), $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade)],
                tooltip: !1,
                tooltipOpts: {
                    defaultTheme: !1
                },
                grid: {
                    show: !1,
                    hoverable: !0,
                    clickable: !0,
                    tickColor: config.chart_lines,
                    borderWidth: 1,
                    borderColor: config.chart_lines
                }
            }
        };

        $scope.area = {
            data: [],
            options: {
                series: {
                    shadowSize: 0,
                    lines: {
                        show: true,
                        lineWidth: false,
                        fill: true
                    },
                    curvedLines: {
                        apply: true,
                        active: true,
                        monotonicFit: false
                    }
                },
                grid: {
                    hoverable: !0,
                    clickable: !0,
                    tickColor: "#f5f5f5",
                    borderWidth: 1,
                    borderColor: "#f5f5f5"
                },
                tooltip: !0,
                tooltipOpts: {
                    defaultTheme: !1,
                    content: '<div class="tooltip-header">%s</div>' +
                        '<div class="tooltip-body">%y items</div>',
                    shifts: {
                        x: -95,
                        y: 25
                    }
                },
                colors: [$rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade), $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade)]
            }
        };

        $scope.areapoints = {
            data: [],
            options: {
                series: {
                    shadowSize: 0,
                    points: {
                        show: true,
                        radius: 3,
                        lineWidth: 1,
                        fillColor: $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade)
                    },
                    lines: {
                        show: false,
                        lineWidth: 0,
                        fill: 0.5,
                        fillColor: config.chart_lines
                    },
                },
                grid: {
                    hoverable: 1,
                    clickable: 1,
                    tickColor: "#f5f5f5",
                    borderWidth: 0,
                    borderColor: "#f5f5f5"
                },
                xaxis: {
                    show: true,
                    font: {
                        color: '#ccc'
                    },
                    position: 'bottom'
                },
                yaxis: {
                    show: true,
                    font: {
                        color: '#ccc'
                    }
                },
                tooltip: !0,
                tooltipOpts: {
                    defaultTheme: !1,
                    content: '<div class="tooltip-header">%s</div>' +
                        '<div class="tooltip-body">%y items</div>',
                    shifts: {
                        x: -95,
                        y: 25
                    }
                },
                colors: [$rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade), $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade)]
            }
        };

        $scope.barChart = {
            data: [],
            options: {
                series: {
                    stack: !0,
                    bars: {
                        show: !0,
                        fill: 1,
                        barWidth: 0.3,
                        align: "center",
                        horizontal: !1,
                        order: 1
                    }
                },
                grid: {
                    hoverable: !0,
                    borderWidth: 1,
                    borderColor: "#f5f5f5"
                },
                tooltip: !0,
                tooltipOpts: {
                    defaultTheme: !1,
                    content: '<div class="tooltip-header">%s</div>' +
                        '<div class="tooltip-body">%y ammount sold</div>',
                    shifts: {
                        x: -95,
                        y: 25
                    }
                },
                colors: [$rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade), $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade), config.color_warning]

            }
        };

        $scope.pieChart = {
            data: [],
            options: {
                series: {
                    pie: {
                        show: !0
                    }
                },
                legend: {
                    show: !0
                },
                grid: {
                    hoverable: !0,
                    clickable: !0
                },
                colors: [$rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade), $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade), config.color_warning, config.danger_color],
                tooltip: !0,
                tooltipOpts: {
                    defaultTheme: !1,
                    content: '<div class="tooltip-header">%s</div>' +
                        '<div class="tooltip-body">%y ammount sold</div>',
                    shifts: {
                        x: -95,
                        y: 25
                    }
                }
            }
        };

        $scope.donutChart = {
            data: [],
            options: {
                series: {
                    pie: {
                        show: !0,
                        innerRadius: 0.5
                    }
                },
                legend: {
                    show: !0
                },
                grid: {
                    hoverable: !0,
                    clickable: !0
                },
                colors: [$rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade), $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade), config.color_warning, config.danger_color],
                tooltip: !0,
                tooltipOpts: {
                    defaultTheme: !1,
                    content: '<div class="tooltip-header">%s</div>' +
                        '<div class="tooltip-body">%y ammount sold</div>',
                    shifts: {
                        x: -95,
                        y: 25
                    }
                }
            }
        };

        $scope.donutChart2 = {
            data: [],
            options: {
                series: {
                    pie: {
                        show: !0,
                        innerRadius: 0.5
                    }
                },
                legend: {
                    show: !1
                },
                grid: {
                    hoverable: !0,
                    clickable: !0
                },
                colors: [$rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade), $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade), config.color_warning, config.danger_color],
                tooltip: !0,
                tooltipOpts: {
                    defaultTheme: !1,
                    content: '<div class="tooltip-header">%s</div>' +
                        '<div class="tooltip-body">%y ammount sold</div>',
                    shifts: {
                        x: -95,
                        y: 25
                    }
                }
            }
        };

        $scope.new_visitors = true;
        $scope.returning_visitors = true;
        $scope.switchClick = function(attr) {
            var choiceContainer = $(".choices");
            choiceContainer.find('input[name=' + attr + ']').click();
        };

        flotSrv.getData(function(data) {
            //Fill in the data from the service
            $scope.line1.data = data.line1.data;
            $scope.line1Small.data = data.line1Small.data;
            $scope.area.data = data.area.data;
            $scope.areapoints.data = data.areapoints.data;
            $scope.barChart.data = data.barChart.data;
            $scope.pieChart.data = data.pieChart.data;
            $scope.donutChart.data = data.donutChart.data;
            $scope.donutChart2.data = data.donutChart2.data;
        });
    }

    angular.module("app.chart.directives")
        .directive("flotChart", [
            function() {
                return {
                    restrict: "A",
                    scope: {
                        data: "=",
                        options: "="
                    },
                    link: function(scope, ele) {
                        var data, options, plot;

                        // hard-code color indices to prevent them from shifting as
                        // countries are turned on/off

                        var datasets;

                        datasets = scope.data;

                        function printChart() {
                            if (scope.data.length > 0) {
                                var i = 0;
                                $.each(datasets, function(key, val) {
                                    val.color = i;
                                    ++i;
                                });

                                // insert checkboxes

                                if ($(ele[0]).parent().find(".choices").length > 0) {

                                    // insert checkboxes
                                    var choiceContainer = $(ele[0]).parent().find(".choices");
                                    var material_choiceContainer = $(ele[0]).parent().find(".choice-switches");

                                    choiceContainer.html("");

                                    $.each(datasets, function(key, val) {

                                        choiceContainer.append("<br/><div class='choice-item'><label for='id" + key + "' class='ui-checkbox'>" +
                                            "<input name='" + key +
                                            "' type='checkbox' id='id" + key + "' checked='checked' value='option1'>" +
                                            "<span>" + val.label + "</span>" +
                                            "</label></div>");
                                    });

                                    var plotAccordingToChoices = function() {

                                        var data_to_push = [];

                                        choiceContainer.find("input:checked").each(function() {
                                            var key = $(this).attr("name");
                                            if (key && datasets[key]) {
                                                data_to_push.push(datasets[key]);
                                            }
                                        });

                                        if (data_to_push.length > 0) {
                                            $.plot(ele[0], data_to_push, scope.options);
                                        }
                                    };

                                    choiceContainer.find("input").click(plotAccordingToChoices);

                                }

                                //plotAccordingToChoices();

                                data = scope.data;
                                options = scope.options;
                                plot = $.plot(ele[0], data, options);
                            }
                        }

                        //Update when charts data changes
                        scope.$watch("data", function(value) {
                            if (value) {
                                printChart();
                            }
                        }, true);
                    }
                };
            }
        ]);

})();
