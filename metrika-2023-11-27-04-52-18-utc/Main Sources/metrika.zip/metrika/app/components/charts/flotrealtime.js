/*
 Flot charts realtime
 http://www.flotcharts.org/
 http://www.flotcharts.org/flot/examples/realtime/index.html
 */

(function() {

    angular.module("app.chart.ctrls")
        .controller("flotChartCtrl.realtime", ["$scope", "config", "$rootScope",
            function($scope, config, $rootScope) {
                $scope.color = $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade);
            }
        ]);

    /*
     Charting directives
     Provides custom directives for charting elements
     */

    angular.module("app.chart.directives")
        .directive("flotChartRealtime", [
            function() {
                return {
                    restrict: "A",
                    link: function(scope, ele) {
                        var data, getRandomData, plot, totalPoints, update, updateInterval;
                        return data = [], totalPoints = 300, getRandomData = function() {
                            var i, prev, res, y;
                            for (data.length > 0 && (data = data.slice(1)); data.length < totalPoints;) {
                                if (data.length > 0) {
                                    prev = data[data.length - 1];
                                } else {
                                    prev = 50;
                                }
                                y = prev + 10 * Math.random() - 5;
                                if (0 > y) {
                                    y = 0;
                                } else {
                                    if (y > 100) {
                                        y = 100;
                                    }
                                }
                                data.push(y);
                            }
                            for (res = [], i = 0; i < data.length;) {
                                res.push([i, data[i]]);
                                ++i;
                            }
                            return res;
                        }, update = function() {
                            plot.setData([getRandomData()]);
                            plot.draw();
                            setTimeout(update, updateInterval);
                        }, data = [], totalPoints = 300, updateInterval = 200, plot = $.plot(ele[0], [getRandomData()], {
                            series: {
                                lines: {
                                    show: !0,
                                    fill: !0
                                },
                                shadowSize: 0
                            },
                            yaxis: {
                                min: 0,
                                max: 100,
                                show: !0,
                                color: "#f5f5f5"
                            },
                            xaxis: {
                                show: !0,
                                color: "#f5f5f5"
                            },
                            tooltip: !0,
                            tooltipOpts: {
                                defaultTheme: !1,
                                content: '<div class="tooltip-header">Realtime</div>' +
                                    '<div class="tooltip-body">%y current items</div>',
                                shifts: {
                                    x: -95,
                                    y: 25
                                }
                            },
                            grid: {
                                hoverable: !0,
                                borderWidth: 1,
                                borderColor: "#f5f5f5"
                            },
                            colors: [scope.color]
                        }), update();
                    }
                };
            }
        ]);

})();
