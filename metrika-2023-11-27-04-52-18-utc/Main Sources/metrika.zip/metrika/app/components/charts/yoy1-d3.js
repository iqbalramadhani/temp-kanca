/*
 D3 line charts angularJs
 https://github.com/n3-charts/line-chart
 color: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade)
 */

(function() {

    angular.module("app.chart.ctrls")
        .controller("yoy1D3Ctrl", ['$scope', 'config', '$rootScope', 'D3YoY1Srv', yoy1D3Ctrl]);

    function yoy1D3Ctrl($scope, config, $rootScope, D3YoY1Srv) {

        //replace $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade)

        $scope.line1 = {
            options: {
                margin: {
                    top: 5
                },
                series: [{
                    axis: "y",
                    dataset: "tolerance",
                    key: "average",
                    label: "Main series",
                    color: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                    type: [
                        "dot",
                        "line"
                    ],
                    id: "tolerance"
                }, {
                    axis: "y",
                    dataset: "tolerance",
                    key: {
                        y0: "extrema_min",
                        y1: "extrema_max"
                    },
                    label: "Extrema",
                    color: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                    type: [
                        "area"
                    ],
                    id: "extrema"
                }],
                axes: {
                    x: {
                        key: "x"
                    },
                    y: {
                        min: 0,
                        max: 40
                    }
                }
            }
        };

        $scope.line1.data = D3YoY1Srv;

        D3YoY1Srv.getData(function(data) {
            // no need to read data because its binded to $scope
            // You can however process something only after the data comes back
        });
    }

})();
