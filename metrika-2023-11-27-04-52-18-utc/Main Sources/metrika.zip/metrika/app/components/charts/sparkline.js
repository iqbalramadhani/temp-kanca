/*
Sparkline charts
http://omnipotent.net/jquery.sparkline/#s-about
*/

(function() {

    angular.module("app.chart.ctrls")
        .controller("sparklineCtrl", ["$scope", "config", "$rootScope", "sparklineSrv", sparklineCtrl]);

    function sparklineCtrl($scope, config, $rootScope, sparklineSrv) {
        $scope.demoData1 = {
            sparkData: [],
            sparkOptions: {
                type: "line",
                lineColor: "#fff",
                highlightLineColor: "#fff",
                fillColor: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                spotColor: !1,
                minSpotColor: !1,
                maxSpotColor: !1,
                width: "100%",
                height: "150px"
            }
        };

        $scope.simpleChart1 = {
            sparkData: [],
            sparkOptions: {
                type: "line",
                lineColor: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                fillColor: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                spotColor: !1,
                minSpotColor: !1,
                maxSpotColor: !1,
                width: "80px",
                height: "50px"
            }
        };
        $scope.simpleChartNoFill = {
            sparkData: [],
            sparkOptions: {
                type: "line",
                lineColor: '#ffffff',
                fillColor: !1,
                resize: true,
                minSpotColor: false,
                maxSpotColor: false,
                highlightSpotColor: $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade),
                highlightLineColor: '#fffff',
                spotColor: '#ffffff',
                valueSpots: {
                    '0:': '#ffffff'
                },
                spotRadius: 3,
                lineWidth: 1,
                width: "90%",
                height: "75px"
            }
        };
        $scope.simpleChart2 = {
            sparkData: [],
            sparkOptions: {
                type: "bar",
                barColor: config.color_warning,
                width: "150px",
                height: "50px"
            }
        };
        $scope.simpleChart2Long = {
            sparkData: [],
            sparkOptions: {
                type: "bar",
                barColor: config.color_warning,
                width: "300px",
                height: "50px"
            }
        };
        $scope.simpleChartwhiteLong = {
            sparkData: [],
            sparkOptions: {
                type: "bar",
                barColor: '#fff',
                width: "300px",
                height: "50px"
            }
        };
        $scope.simpleChart2danger = {
            sparkData: [],
            sparkOptions: {
                type: "bar",
                barColor: config.danger_color,
                width: "150px",
                height: "50px"
            }
        };
        $scope.simpleChart2dangerLong = {
            sparkData: [],
            sparkOptions: {
                type: "bar",
                barColor: config.danger_color,
                width: "300px",
                height: "50px"
            }
        };
        $scope.simpleChartlong = {
            sparkData: [],
            sparkOptions: {
                type: "bar",
                barColor: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                width: "250px",
                height: "30px"
            }
        };
        $scope.simpleChart2long = {
            sparkData: [],
            sparkOptions: {
                type: "bar",
                barColor: config.color_warning,
                width: "200px",
                height: "30px"
            }
        };
        $scope.simpleChart2info = {
            sparkData: [],
            sparkOptions: {
                type: "bar",
                barColor: "#FFFFFF",
                width: "100px",
                height: "30px"
            }
        };
        $scope.simpleChart3 = {
            sparkData: [],
            sparkOptions: {
                type: "pie",
                sliceColors: [$rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade), $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade), config.color_warning, config.danger_color, "#CCCCCC", "#365340"],
                width: "50px",
                height: "50px"
            }
        };
        $scope.tristateChart1 = {
            sparkData: [],
            sparkOptions: {
                type: "tristate",
                posBarColor: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                negBarColor: $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade),
                width: "100%",
                height: "50px"
            }
        };
        $scope.tristateChart1Long = {
            sparkData: [],
            sparkOptions: {
                type: "tristate",
                posBarColor: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                negBarColor: $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade),
                width: "100%",
                height: "50px"
            }
        };
        $scope.largeChart1 = {
            sparkData: [],
            sparkOptions: {
                type: "line",
                lineColor: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                highlightLineColor: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                fillColor: $rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade),
                spotColor: !1,
                minSpotColor: !1,
                maxSpotColor: !1,
                width: "100%",
                height: "150px"
            }
        };
        $scope.largeChart2 = {
            sparkData: [],
            sparkOptions: {
                type: "bar",
                barColor: $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade),
                barWidth: 10,
                width: "100%",
                height: "150px"
            }
        };
        $scope.largeChart3 = {
            sparkData: [],
            sparkOptions: {
                type: "pie",
                sliceColors: [$rootScope.getMaterialColor(config.md_primary.base, config.md_primary.shade), , $rootScope.getMaterialColor(config.md_accent.base, config.md_accent.shade), , config.color_warning, config.danger_color, "#CCCCCC", "#365340"],
                width: "150px",
                height: "150px"
            }
        };

        sparklineSrv.getData(function(data) {
            $scope.demoData1.sparkData = data.demoData1;
            $scope.simpleChart1.sparkData = data.simpleChart1;
            $scope.simpleChartNoFill.sparkData = data.simpleChartNoFill;
            $scope.simpleChart2.sparkData = data.simpleChart2;
            $scope.simpleChart2Long.sparkData = data.simpleChart2Long;
            $scope.simpleChartwhiteLong.sparkData = data.simpleChartwhiteLong;
            $scope.simpleChart2danger.sparkData = data.simpleChart2danger;
            $scope.simpleChart2dangerLong.sparkData = data.simpleChart2dangerLong;
            $scope.simpleChartlong.sparkData = data.simpleChartlong;
            $scope.simpleChart2long.sparkData = data.simpleChart2long;
            $scope.simpleChart2info.sparkData = data.simpleChart2info;
            $scope.simpleChart3.sparkData = data.simpleChart3;
            $scope.tristateChart1.sparkData = data.tristateChart1;
            $scope.tristateChart1Long.sparkData = data.tristateChart1Long;
            $scope.largeChart1.sparkData = data.largeChart1;
            $scope.largeChart2.sparkData = data.largeChart2;
            $scope.largeChart3.sparkData = data.largeChart3;
        });
    }

    angular.module("app.chart.directives")
        .directive("sparkline", [
            function() {
                return {
                    scope: {
                        sparkData: "=",
                        sparkOptions: "="
                    },
                    link: function(scope, ele) {
                        var data, options, sparkResize, sparklineDraw;

                        data = scope.sparkData;
                        options = scope.sparkOptions;
                        sparkResize = void 0;
                        sparklineDraw = function() {
                            if (data.length > 0) {
                                ele.sparkline(data, options);
                            }
                        };
                        $(window).resize(function() {
                            return clearTimeout(sparkResize), sparkResize = setTimeout(sparklineDraw, 200);
                        });

                        //Update when charts data changes
                        scope.$watch("sparkData", function(value) {
                            if (value) {
                                data = value;
                                sparklineDraw();
                            }
                        }, true);
                    }
                };
            }
        ]);
})();
