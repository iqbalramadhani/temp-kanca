/*
 * User specific elements
 */

(function() {

    angular.module('app.user', ['ngMaterial', 'ngMessages'])
        .component('userTabs', {
            templateUrl: 'app/components/user/templates/user-tabs.html',
            controllerAs: 'usertabs',
            controller: function() {
                this.next = function() {
                    this.data.selectedIndex = Math.min($scope.data.selectedIndex + 1, 2);
                };
                this.previous = function() {
                    this.data.selectedIndex = Math.max($scope.data.selectedIndex - 1, 0);
                };
            }
        })
        .component('userContactChips', {
            templateUrl: 'app/components/user/templates/user-contact-chips.html',
            controllerAs: 'userchips',
            controller: function($timeout, $q) {
                var self = this;
                self.querySearch = querySearch;
                self.allContacts = loadContacts();
                self.contacts = [];
                self.filterSelected = true;
                /**
                 * Search for contacts.
                 */
                function querySearch(query) {
                    var results = query ?
                        self.allContacts.filter(createFilterFor(query)) : [];
                    return results;
                }

                /**
                 * Create filter function for a query string
                 */
                function createFilterFor(query) {
                    var lowercaseQuery = angular.lowercase(query);
                    return function filterFn(contact) {
                        return (contact._lowername.indexOf(lowercaseQuery) != -1);
                    };
                }

                function loadContacts() {
                    var contacts = [
                        'Marina Augustine',
                        'Oddr Sarno',
                        'Nick Giannopoulos',
                        'Narayana Garner',
                        'Anita Gros',
                        'Megan Smith',
                        'Tsvetko Metzger',
                        'Hector Simek',
                        'Some-guy withalongalastaname'
                    ];
                    return contacts.map(function(c, index) {
                        var cParts = c.split(' ');
                        var contact = {
                            name: c,
                            email: cParts[0][0].toLowerCase() + '.' + cParts[1].toLowerCase() + '@example.com',
                            image: 'http://lorempixel.com/50/50/people?' + index
                        };
                        contact._lowername = contact.name.toLowerCase();
                        return contact;
                    });
                }
            }
        });
})();
