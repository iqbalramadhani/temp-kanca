/*
 App Form validations
 Validator functions for form elements (signIn,signUp and custom forms)
 */

(function() {

    angular.module("app.form.validation", [])
        .controller("formConstraintsCtrl", formConstraintsCtrl)
        .controller("signinCtrl", signinCtrl)
        .controller("signupCtrl", signupCtrl);

    /**
     * The controller function for formConstraintsCtrl
     */
    function formConstraintsCtrl() {
        var original;
        this.form = {
            required: "",
            minlength: "",
            maxlength: "",
            length_rage: "",
            type_something: "",
            confirm_type: "",
            foo: "",
            email: "",
            url: "",
            num: "",
            minVal: "",
            maxVal: "",
            valRange: "",
            pattern: ""
        };
        this.original = angular.copy(this.form);
        this.revert = function() {
            return this.form = angular.copy(original), this.form_constraints.$setPristine();
        };
        this.canRevert = function() {
            return !angular.equals(this.form, original) || !this.form_constraints.$pristine;
        };
        this.canSubmit = function() {
            return this.form_constraints.$valid && !angular.equals(this.form, original);
        };
    }

    /**
     * The controller function for signinCtrl
     */
    function signinCtrl() {
        var original;
        this.user = {
            email: "",
            password: ""
        };
        this.showInfoOnSubmit = !1;
        this.original = angular.copy(this.user);
        this.revert = function() {
            this.user = angular.copy(original);
            this.form_signin.$setPristine();
        };
        this.canRevert = function() {
            return !angular.equals(this.user, original) || !this.form_signin.$pristine;
        };
        this.canSubmit = function() {
            return this.form_signin.$valid && !angular.equals(this.user, original);
        };
        this.submitForm = function() {
            this.showInfoOnSubmit = !0;
            this.revert();
        };
    }

    /**
     * The controller function for signupCtrl
     */
    function signupCtrl() {
        var original;
        this.user = {
            name: "",
            email: "",
            password: "",
            confirmPassword: "",
            age: ""
        };
        this.showInfoOnSubmit = !1;
        this.original = angular.copy(this.user);
        this.revert = function() {
            this.user = angular.copy(original);
            this.form_signup.$setPristine();
            this.form_signup.confirmPassword.$setPristine();
        };
        this.canRevert = function() {
            return !angular.equals($scope.user, original) || !this.form_signup.$pristine;
        };
        this.canSubmit = function() {
            return this.form_signup.$valid && !angular.equals(this.user, original);
        };
        this.submitForm = function() {
            this.showInfoOnSubmit = !0;
            this.revert();
        };
    }



    /*
     App Form Ui Directives
     Custom directives for Form Ui elements
     */

    angular.module("app.ui.form.directives", [])
        .directive("uiRangeSlider", [uiRangeSlider]).directive("uiFileUpload", [uiFileUpload])
        .directive("uiSpinner", [uiSpinner])
        .directive("uiWizardForm", [uiWizardForm])
        .directive('ngEnter', ngEnter)
        .directive("passwordVerify", passwordVerify);

    /**
     * Range slider for forms
     * @return {Function} The directive for the range slider
     */
    function uiRangeSlider() {
        return {
            restrict: "A",
            link: function(scope, ele) {
                return ele.slider();
            }
        };
    }

    /**
     * UI File Upload directive
     * @return {Function} The UI File Upload directive
     */
    function uiFileUpload() {
        return {
            restrict: "A",
            link: function(scope, ele) {
                return ele.bootstrapFileInput();
            }
        };
    }

    /**
     * UI Spinner directive
     * @return {Function} The UI Spinner directive
     */
    function uiSpinner() {
        return {
            restrict: "A",
            compile: function(ele) {
                return ele.addClass("ui-spinner"), {
                    post: function() {
                        return ele.spinner();
                    }
                };
            }
        };
    }

    /**
     * UI Wizard form directive
     * @return {Function} UI Wizard form directive
     */
    function uiWizardForm() {
        return {
            link: function(scope, ele) {
                return ele.steps();
            }
        };
    }

    /**
     * A custom directive for pressing enter on inputs
     * @return {Function} The directive definition
     */
    function ngEnter() {
        return function(scope, element, attrs) {
            element.bind("keydown keypress", function(event) {
                if (event.which === 13) {
                    scope.$apply(function() {
                        scope.$eval(attrs.ngEnter, {
                            'event': event
                        });
                    });

                    event.preventDefault();
                }
            });
        };
    }


    /**
     * The directive for passwordVerify
     * @return {Object} The directive definition
     */
    function passwordVerify() {
        return {
            require: "ngModel",
            link: function(scope, element, attrs, ctrl) {
                ctrl.$parsers.unshift(function(viewValue) {
                    var origin = scope.$eval(attrs.passwordVerify);
                    if (origin !== viewValue) {
                        ctrl.$setValidity("passwordVerify", false);
                        return undefined;
                    } else {
                        ctrl.$setValidity("passwordVerify", true);
                        return viewValue;
                    }
                });

            }
        };
    }

})();
