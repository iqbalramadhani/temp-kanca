/*
* Code from material angular
https://material.angularjs.org/latest/demo/tooltip
*/

(function() {

    angular.module("app.tooltips", ['ngMaterial', 'ngMessages'])
        .controller('TooltipDemo',
            function($scope) {
                $scope.demo = {};
            })
        .controller('TooltipCtrl',
            function($scope) {
                $scope.demo = {};
            });
})();
