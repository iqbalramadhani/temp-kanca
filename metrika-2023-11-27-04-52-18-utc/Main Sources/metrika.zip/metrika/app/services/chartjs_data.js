angular.module("app.services")
    .factory("chartJsSrv", chartJsSrv);
    
function chartJsSrv($http) {
     /**************************
     Gets data for d3 line charts
     **************************/

    var ChartJsObj = {},
        rawData = {};

    /**************************
     Get data from the .json files (Replace by your own webserver)
     **************************/

    ChartJsObj.getData = function(callback) {

        $http.get('dist/data/chartjs.json').success(function(data) {

            rawData = data;
            ChartJsObj.rawData = rawData;

            callback(data);

        });

    };

    return ChartJsObj;
}
