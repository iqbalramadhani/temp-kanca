angular.module("app.services")
    .factory("gaugesSrv", gaugesSrv);
    
function gaugesSrv($http) {
     /**************************
     Gets data for d3 line charts
     **************************/

    var GaugesObj = {},
        rawData = {};

    /**************************
     Get data from the .json files (Replace by your own webserver)
     **************************/

    GaugesObj.getData = function(callback) {

        $http.get('dist/data/gauges.json').success(function(data) {

            rawData = data;
            GaugesObj.rawData = rawData;

            callback(data);

        });

    };

    return GaugesObj;
}
