angular.module("app.services")
    .factory("flotSrv", flotSrv);
    
function flotSrv($http) {
     /**************************
     Gets data for d3 line charts
     **************************/

    var FlotObj = {},
        rawData = {};

    /**************************
     Get data from the .json files (Replace by your own webserver)
     **************************/

    FlotObj.getData = function(callback) {

        $http.get('dist/data/flot.json').success(function(data) {

            rawData = data;
            FlotObj.rawData = rawData;

            callback(data);

        });

    };

    return FlotObj;
}
