angular.module("app.services")
    .factory("D3PieSrv", D3PieSrv)
    .factory("D3YoY1Srv", D3YoY1Srv)
    .factory("D3LineSrv", D3LineSrv);

function D3YoY1Srv($http) {
     /**************************
     Gets data for d3 line charts
     **************************/

    var D3YoY1Obj = {},
        rawData = {};

    /**************************
     Get data from the .json files (Replace by your own webserver)
     **************************/

    D3YoY1Obj.getData = function(callback) {

        $http.get('dist/data/d3yoy1.json').success(function(data) {

            rawData = data;
            D3YoY1Obj.rawData = rawData;

            callback(data);

        });

    };

    return D3YoY1Obj;
}

function D3LineSrv($http) {
     /**************************
     Gets data for d3 line charts
     **************************/

    var D3LineObj = {},
        rawData = {};

    /**************************
     Get data from the .json files (Replace by your own webserver)
     **************************/

    D3LineObj.getData = function(callback) {

        $http.get('dist/data/d3line.json').success(function(data) {

            rawData = data;
            D3LineObj.rawData = rawData;

            callback(data);

        });

    };

    return D3LineObj;
}

function D3PieSrv($http) {

    /**************************
     Gets data for d3 pie charts
     **************************/

    var D3PieObj = {},
        rawData = {};

    /**************************
     Get data from the .json files (Replace by your own webserver)
     **************************/

    D3PieObj.getData = function(callback) {

        $http.get('dist/data/d3pie.json').success(function(data) {

            rawData = data;
            D3PieObj.rawData = rawData;

            callback(data);

        });

    };

    return D3PieObj;

}