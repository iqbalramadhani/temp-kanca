angular.module("app.services")
    .factory("morrisSrv", morrisSrv);
    
function morrisSrv($http) {
     /**************************
     Gets data for d3 line charts
     **************************/

    var MorrisObj = {},
        rawData = {};

    /**************************
     Get data from the .json files (Replace by your own webserver)
     **************************/

    MorrisObj.getData = function(callback) {

        $http.get('dist/data/morris.json').success(function(data) {

            rawData = data;
            MorrisObj.rawData = rawData;

            callback(data);

        });

    };

    return MorrisObj;
}
