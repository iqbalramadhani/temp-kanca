angular.module("app.services")
    .factory("sparklineSrv", sparklineSrv);
    
function sparklineSrv($http) {
     /**************************
     Gets data for d3 line charts
     **************************/

    var SparklineObj = {},
        rawData = {};

    /**************************
     Get data from the .json files (Replace by your own webserver)
     **************************/

    SparklineObj.getData = function(callback) {

        $http.get('dist/data/sparkline.json').success(function(data) {

            rawData = data;
            SparklineObj.rawData = rawData;

            callback(data);

        });

    };

    return SparklineObj;
}
