/**************************
 Initialize the Angular App
 **************************/

var app = angular.module("app", ["ngRoute", "ui.router", "ngResource", "ngAnimate", "ngAria", "ngSanitize", "ngMessages", "ngMaterial",
        "easypiechart", "mgo-angular-wizard", "ngMap", "pascalprecht.translate",
        "app.config", "app.navigation", "app.navigation.sidenav", "app.header",
        "app.services", "app.subheader", "app.tabs", "app.tooltips", "app.autocomplete", "app.dialog", "app.chat", "app.form.material", "n3-pie-chart", "n3-line-chart",
        //To confirm these ones make sure we need them
        "ui.tree", "app.ui.form.directives", "app.ui.tree", "app.form.validation",
        "app.bottomsheet", "app.chips", "app.toast", "app.calendar", "app.fabs",
        "app.ui.maps", "app.ui.progress", "app.ui.toolbar",
        "app.user", "app.colorswitcher", "app.site_autocomplete",
        "app.tables", "app.map", "todomvc", "app.chart.ctrls", "app.chart.directives", "countTo", "app.music"
    ])
    .run(["$rootScope", "$location", "$mdColorPalette",
        function($rootScope, $location, $mdColorPalette) {

            $(document).ready(function(config) {

                setTimeout(function() {
                    $('.page-loading-overlay').addClass("loaded");
                    $('.load_circle_wrapper').addClass("loaded");
                }, 1000);

            });

            $rootScope.app_name = "Metrika";

            $rootScope.getMaterialColor = function(base, shade) {
                var color = $mdColorPalette[base][shade].value;
                return 'rgb(' + color[0] + ',' + color[1] + ',' + color[2] + ')';
            };

            $rootScope.RGB2HTML = function(rgb) {
                rgb = rgb.match(/^rgba?[\s+]?\([\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?/i);
                return (rgb && rgb.length === 4) ? "#" +
                    ("0" + parseInt(rgb[1], 10).toString(16)).slice(-2) +
                    ("0" + parseInt(rgb[2], 10).toString(16)).slice(-2) +
                    ("0" + parseInt(rgb[3], 10).toString(16)).slice(-2) : '';
            };

        }
    ]).config(function($stateProvider, $urlRouterProvider) {
        //
        // For any unmatched url, redirect to /dashboard
        $urlRouterProvider.otherwise("/dashboard");
        //
        // Now set up the states
        $stateProvider
            .state('dashboard', {
                url: "/dashboard",
                templateUrl: "app/views/dashboards/dashboard.html"
            })
            .state('dashboard1', {
                url: "/dashboard/dashboard1",
                templateUrl: "app/views/dashboards/dashboard1.html"
            })
            .state('dashboard2', {
                url: "/dashboard/dashboard2",
                templateUrl: "app/views/dashboards/dashboard2.html"
            })
            .state('buttons', {
                url: "/ui/buttons",
                templateUrl: "app/views/ui_elements/buttons.html"
            })
            .state('fabs', {
                url: "/ui/fabs",
                templateUrl: "app/views/ui_elements/fabs.html"
            })
            .state('cards', {
                url: "/ui/cards",
                templateUrl: "app/views/ui_elements/cards.html"
            })
            .state('colors', {
                url: "/ui/colors",
                templateUrl: "app/views/ui_elements/color.html"
            })
            .state('widgets', {
                url: "/ui/widgets",
                templateUrl: "app/views/ui_elements/widgets.html"
            })
            .state('chips', {
                url: "/ui/chips",
                templateUrl: "app/views/ui_elements/chips.html"
            })
            .state('progress', {
                url: "/ui/progress",
                templateUrl: "app/views/ui_elements/progress.html"
            })
            .state('messages', {
                url: "/ui/messages",
                templateUrl: "app/views/ui_elements/messages.html"
            })
            .state('tabs', {
                url: "/ui/tabs",
                templateUrl: "app/views/ui_elements/tabs.html"
            })
            .state('timeline', {
                url: "/ui/timeline",
                templateUrl: "app/views/ui_elements/timeline.html"
            })
            .state('icons', {
                url: "/ui/icons",
                templateUrl: "app/views/ui_elements/icons.html"
            })
            .state('grids', {
                url: "/ui/grids",
                templateUrl: "app/views/ui_elements/grids.html"
            })
            .state('profile', {
                url: "/pages/profile",
                templateUrl: "app/views/pages/profile.html"
            })
            .state('contact', {
                url: "/pages/contact",
                templateUrl: "app/views/pages/contact.html"
            })
            .state('signin', {
                url: "/login",
                templateUrl: "app/views/pages/signin.html"
            })
            .state('signup', {
                url: "/register",
                templateUrl: "app/views/pages/signup.html"
            })
            .state('forgot-password', {
                url: "/forgot-password",
                templateUrl: "app/views/pages/forgot-password.html"
            })
            .state('lock-screen', {
                url: "/lock-screen",
                templateUrl: "app/views/pages/lock.html"
            })
            .state('404', {
                url: "/404",
                templateUrl: "app/views/pages/404.html"
            })
            .state('500', {
                url: "/500",
                templateUrl: "app/views/pages/500.html"
            })
            .state('tables-static', {
                url: "/tables/static",
                templateUrl: "app/views/tables/static.html"
            })
            .state('tables-responsive', {
                url: "/tables/responsive",
                templateUrl: "app/views/tables/responsive.html"
            })
            .state('tables-dynamic', {
                url: "/tables/dynamic",
                templateUrl: "app/views/tables/dynamic.html"
            })
            .state('form-elements', {
                url: "/forms/elements",
                templateUrl: "app/views/forms/elements.html"
            })
            .state('form-validation', {
                url: "/forms/validation",
                templateUrl: "app/views/forms/validation.html"
            })
            .state('flot-charts', {
                url: "/charts/flot",
                templateUrl: "app/views/charts/flot.html"
            })
            .state('chartjs', {
                url: "/charts/chartjs",
                templateUrl: "app/views/charts/chartjs.html"
            })
            .state('morris', {
                url: "/charts/morris",
                templateUrl: "app/views/charts/morris.html"
            })
            .state('d3', {
                url: "/charts/d3",
                templateUrl: "app/views/charts/d3.html"
            })
            .state('other-charts', {
                url: "/charts/other",
                templateUrl: "app/views/charts/charts.html"
            })
            .state('chat', {
                url: "/chat",
                templateUrl: "app/views/chat/chat.html"
            })
            .state('tasks', {
                url: "/tasks",
                templateUrl: "app/components/tasks/tasks.html",
                controller:'TodoCtrl',
                resolve: {
                    store: function(todoStorage) {
                        // Get the correct module (API or localStorage).
                        return todoStorage.then(function(module) {
                            module.get(); // Fetch the todo records in the background.
                            return module;
                        });
                    }
                }
            })
            .state('tasks.active', {
                url: "/active",
                templateUrl: "app/components/tasks/tasks.html",
                controller:'TodoCtrl',
                resolve: {
                    store: function(todoStorage) {
                        // Get the correct module (API or localStorage).
                        return todoStorage.then(function(module) {
                            module.get(); // Fetch the todo records in the background.
                            return module;
                        });
                    }
                }
            })
            .state('tasks.completed', {
                url: "/completed",
                templateUrl: "app/components/tasks/tasks.html",
                controller:'TodoCtrl',
                resolve: {
                    store: function(todoStorage) {
                        // Get the correct module (API or localStorage).
                        return todoStorage.then(function(module) {
                            module.get(); // Fetch the todo records in the background.
                            return module;
                        });
                    }
                }
            });

            var routeTasksConfig = {
                controller: 'TodoCtrl',
                templateUrl: "app/components/tasks/tasks.html",
                resolve: {
                    store: function(todoStorage) {
                        // Get the correct module (API or localStorage).
                        return todoStorage.then(function(module) {
                            module.get(); // Fetch the todo records in the background.
                            return module;
                        });
                    }
                }
            };

    })
    .config(["$routeProvider", "$translateProvider",
        function($routeProvider, $translateProvider) {

            // Register a loader for the static files
            // So, the module will search missing translation tables under the specified urls.
            // Those urls are [prefix][langKey][suffix].
            $translateProvider.useStaticFilesLoader({
                prefix: 'l10n/',
                suffix: '.json'
            });

            // Enable escaping of HTML
            $translateProvider.useSanitizeValueStrategy('escape');

            // Tell the module what language to use by default
            $translateProvider.preferredLanguage('us');

            var routeTasksConfig = {
                controller: 'TodoCtrl',
                templateUrl: "app/components/tasks/tasks.html",
                resolve: {
                    store: function(todoStorage) {
                        // Get the correct module (API or localStorage).
                        return todoStorage.then(function(module) {
                            module.get(); // Fetch the todo records in the background.
                            return module;
                        });
                    }
                }
            };

            return $routeProvider.when('/tasks', routeTasksConfig).when('/tasks/:status', routeTasksConfig);
        }
    ]).config(function($mdThemingProvider, $mdGestureProvider, config) {

        $mdThemingProvider.alwaysWatchTheme(true);

        $mdGestureProvider.skipClickHijack();

        $mdThemingProvider.theme('default')
            .primaryPalette(config.md_primary.base, {
                'default': config.md_primary.shade
            })
            .accentPalette(config.md_accent.base, {
                'default': config.md_accent.shade
            });
    });
